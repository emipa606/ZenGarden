# Zen Garden

This mod adds various zen and rock garden themed decorations. Researching stonecutting unlocks everything.

![Preview](http://i.imgur.com/uWH6wYH.png)